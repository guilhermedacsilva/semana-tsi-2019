import base64, codecs
magic = 'CnByaW50KCJFc3RlIGPDs2RpZ28gUHl0aG9uIHBvZGUgcmV2ZWxhciB1bWEgZnJhc2Ugc2VjcmV0YSEgRGVzY3VicmEhIikKCnZhbG9yQSA9IGludChpbnB1dCgiQSAtIERpZ2l0ZSB1bSB2YWxvciBpbnRlaXJvIHF1YWxxdWVyOiAiKSkKdmFsb3JCID0gaW50KGlucHV0KCJCIC0gRGlnaXRlIHVtIHZhbG9yIGludGVpcm8gc'
love = 'KIuoUS1MKV6VPVcXDbXpUWcoaDbVxSfM29lnKEgolOmMJAlMKEiVTAuoTA1oTShMT8tYv4hVSgin10vXDc2LJkipxRtCFO2LJkipxRtXlNkZjclMKA1oUEuMT9OVQ0tqzSfo3WOVPbtqzSfo3WPVPftqzSfo3WOPaMuoT9lDvN9VUMuoT9lDvNeVQR3PaWyp3IfqTSxo0VtCFO2LJkipxVtXvNbqzSfo3WOVP0tqzSfo3WPXDbXpz'
god = 'VzdWx0YWRvID0gKHJlc3VsdGFkb0EtcmVzdWx0YWRvQikKcHJpbnQoIkVzcGVyYXZhIG8gcmVzdWx0YWRvIDAgKHplcm8pLCB2b2PDqiBlbmNvbnRyb3U6ICIsc3RyKHJlc3VsdGFkbykpCmlmIChyZXN1bHRhZG8gPT0gMCk6CiAgIHByaW50KCJNdWl0byBiZW0sIHZvY8OqIGVuY29udHJvdSBhIGZyYXNlIHNlY3JldGEhIDo'
destiny = 'cVvxXVPNtpUWcoaDbVxMlLKAyVUAyL3WyqTR6VREcLJ50MFOxMFO1oJRtMTyznJA1oTEuMTHfVUA1LaA0nKE1LFOiVT7Qb28tL29hp2yaolOjo3Vtqz91VUEyoaEupvOiqKElLFO2MKbhVvxXMJkmMGbXVPNtpUWcoaDbVxyhMzIfnKcgMJ50MFO2o2CQdvOhj6AiVTIhL29hqUWiqFOuVTMlLKAyVUAyL3WyqTRuVQbiVvxXPt=='
joy = '\x72\x6f\x74\x31\x33'
trust = eval('\x6d\x61\x67\x69\x63') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x6c\x6f\x76\x65\x2c\x20\x6a\x6f\x79\x29') + eval('\x67\x6f\x64') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x64\x65\x73\x74\x69\x6e\x79\x2c\x20\x6a\x6f\x79\x29')
eval(compile(base64.b64decode(eval('\x74\x72\x75\x73\x74')),'<string>','exec'))
